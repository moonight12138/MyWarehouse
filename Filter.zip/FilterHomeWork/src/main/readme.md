# 登录过滤器和Servlet示例

本项目演示了一个使用Jakarta Servlet和过滤器来管理用户认证和访问控制的简单Web应用程序。

## 关键组件

1. **LoginFilter**：一个过滤器，用于在允许访问某些页面之前检查用户是否已登录。
2. **LoginServlet**：处理用户登录的servlet。
3. **PrivateServlet**：显示只有登录用户才能访问的私有页面的servlet。
4. **PublicServlet**：显示所有用户（无论是否登录）都能访问的公共页面的servlet。
5. **RegisterServlet**：显示注册页面的servlet。

## 设置

要运行此项目，您需要一个与Jakarta EE兼容的应用服务器，如Apache Tomcat或Eclipse GlassFish。请按照以下步骤操作：

1. 将项目导入您的IDE。
2. 配置项目以使用适当的应用服务器。
3. 将项目部署到服务器。

## 过滤器配置

`LoginFilter`在`web.xml`文件中或通过注解（`@WebFilter`）配置。它检查请求URI是否以指定的静态扩展名之一结尾（例如`/login`、`/register`、`/public`），如果是，则允许访问而不需要登录。对于其他URI，它会检查是否有带有`username`属性的活动会话。

## Servlets

- **LoginServlet**：映射到`/login` URL模式。它认证用户并在成功登录后设置会话属性。
- **PrivateServlet**：映射到`/private` URL模式。它检查用户是否已登录，并显示一条私人消息。
- **PublicServlet**：映射到`/public` URL模式。所有用户（无论是否登录）都可以访问。
- **RegisterServlet**：映射到`/register` URL模式。它显示注册页面。

## 编码处理

`GetRequestWrapper`类用于处理GET和POST请求的字符编码，确保根据指定的`encoding`参数正确解码和编码参数。

## 运行应用程序

部署后，您可以使用Web浏览器访问应用程序：

- 访问`/public`查看公共页面。
- 访问`/login`使用用户名“admin”和密码“123”登录。
- 登录后，访问`/private`查看私有页面。
- 访问`/register`查看注册页面。

---

# 登录过滤器和Servlet示例

本项目展示了一个使用Jakarta Servlet和过滤器来管理用户认证和访问控制的简单Web应用程序。

## 核心组件

1. **LoginFilter**：一个过滤器，用于在允许访问某些页面之前检查用户是否已登录。
2. **LoginServlet**：处理用户登录的Servlet。
3. **PrivateServlet**：显示只有登录用户才能访问的私有页面的Servlet。
4. **PublicServlet**：显示所有用户（无论是否登录）都能访问的公共页面的Servlet。
5. **RegisterServlet**：显示注册页面的Servlet。

## 设置

要运行此项目，您需要一个与Jakarta EE兼容的应用服务器，如Apache Tomcat或Eclipse GlassFish。请按照以下步骤操作：

1. 将项目导入您的IDE。
2. 配置项目以使用适当的应用服务器。
3. 将项目部署到服务器。

## 过滤器配置

`LoginFilter`在`web.xml`文件中或通过注解（`@WebFilter`）配置。它检查请求URI是否以指定的静态扩展名之一结尾（例如`/login`、`/register`、`/public`），如果是，则允许访问而不需要登录。对于其他URI，它会检查是否有带有`username`属性的活动会话。

## Servlets

- **LoginServlet**：映射到`/login` URL模式。它认证用户并在成功登录后设置会话属性。
- **PrivateServlet**：映射到`/private` URL模式。它检查用户是否已登录，并显示一条私人消息。
- **PublicServlet**：映射到`/public` URL模式。所有用户（无论是否登录）都可以访问。
- **RegisterServlet**：映射到`/register` URL模式。它显示注册页面。

## 编码处理

`GetRequestWrapper`类用于处理GET和POST请求的字符编码，确保根据指定的`encoding`参数正确解码和编码参数。

## 运行应用程序

部署后，您可以使用Web浏览器访问应用程序：

- 访问`/public`查看公共页面。
- 访问`/login`使用用户名“admin”和密码“123”登录。
- 登录后，访问`/private`查看私有页面。
- 访问`/register`查看注册页面。
