package org.example.listenerhomework;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet(urlPatterns = "/test")
public class TestServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 模拟一些处理逻辑
        try {
            Thread.sleep(1000); // 模拟处理时间
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        resp.getWriter().write("test Servlet"); // 响应内容
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}