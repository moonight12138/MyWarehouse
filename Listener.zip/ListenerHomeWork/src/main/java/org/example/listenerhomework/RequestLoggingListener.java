package org.example.listenerhomework;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Date;

@WebListener
public class RequestLoggingListener implements ServletRequestListener {

    private long startTime; // 记录请求开始的时间戳

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        startTime = System.currentTimeMillis(); // 获取当前时间戳作为开始时间
        System.out.println("请求开始时间: " + new Date(startTime)); // 打印请求开始时间
        System.out.println("客户端IP地址: " + request.getRemoteAddr()); // 打印客户端IP地址
        System.out.println("请求方法: " + request.getMethod()); // 打印请求方法（GET, POST 等）
        System.out.println("请求URI: " + request.getRequestURI()); // 打印请求URI
        System.out.println("查询字符串: " + request.getQueryString()); // 打印查询字符串
        System.out.println("User-Agent: " + request.getHeader("User-Agent")); // 打印User-Agent
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        long endTime = System.currentTimeMillis(); // 获取当前时间戳作为结束时间
        long processingTime = endTime - startTime; // 计算处理时间
        System.out.println("请求结束时间: " + new Date(endTime)); // 打印请求结束时间
        System.out.println("请求处理时间: " + processingTime + " 毫秒"); // 打印请求处理时间
    }
}