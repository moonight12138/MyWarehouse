  # 请求日志监听器示例

本项目展示了一个使用Jakarta Servlet API中的监听器（Listener）来记录HTTP请求的开始和结束时间，以及请求的详细信息。

## 核心组件

- **RequestLoggingListener**：一个实现了`ServletRequestListener`接口的监听器，用于记录请求的初始化和销毁事件。
- **TestServlet**：一个简单的Servlet，用于处理HTTP请求并模拟一些处理逻辑。

## 功能描述

- **RequestLoggingListener**：
    - 在请求初始化时记录开始时间，并打印请求的详细信息，包括客户端IP地址、请求方法、请求URI、查询字符串和User-Agent。
    - 在请求销毁时计算请求的处理时间，并打印请求的结束时间和处理时间。

- **TestServlet**：
    - 处理GET和POST请求，模拟一些处理逻辑，例如通过`Thread.sleep(1000)`模拟处理时间。
    - 响应内容为简单的文本“test Servlet”。

## 运行说明

1. 将项目导入您的IDE。
2. 配置项目以使用适当的Jakarta EE兼容的应用服务器。
3. 部署项目到服务器。
4. 使用Web浏览器或工具（如curl或Postman）访问`/test`路径，以触发请求日志记录。

## 示例输出

请求初始化时的输出示例：
```
请求开始时间: Wed Oct 11 14:30:00 CST 2024
客户端IP地址: 127.0.0.1
请求方法: GET
请求URI: /test
查询字符串: null
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)
```

请求销毁时的输出示例：
```
请求结束时间: Wed Oct 11 14:30:01 CST 2024
请求处理时间: 1000 毫秒
```

