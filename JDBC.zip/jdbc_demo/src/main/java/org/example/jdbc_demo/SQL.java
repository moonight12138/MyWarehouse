package org.example.jdbc_demo;
import java.sql.*;

public class SQL {

    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "zhouying1379";

        String sql_insert = "insert into teacher values (?,?,?,?)";
        String sql_select = "select * from teacher";
        String sql_update = "update teacher set name = ? where id = ?";
        String sql_delete = "delete from teacher where id = ?";

        try(Connection conn = DriverManager.getConnection(url,user,password);) {
            conn.setAutoCommit(false);
            setSql_insert(conn,sql_insert);//增
            setSql_select(conn,sql_select);//查
            setSql_update(conn,sql_update);//改
            setSql_delete(conn,sql_delete);//删
            batch_insert(conn,sql_insert);//批量插入
            roll_select(conn,sql_select);//可滚动结果集
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void setSql_insert(Connection conn, String sql) throws SQLException {
        try(PreparedStatement ps = conn.prepareStatement(sql);
        ) {
            ps.setInt(1,1);
            ps.setString(2,"张三");
            ps.setString(3,"法律");
            ps.setString(4,"2000-01-01");
            ps.executeUpdate();
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            e.printStackTrace();
        }
    }
    public static void setSql_select(Connection conn,String sql){
        try(PreparedStatement ps = conn.prepareStatement(sql);
        ) {
            try(ResultSet rs = ps.executeQuery();) {
                while (rs.next()){
                    System.out.println(rs.getObject(1)+" "+rs.getObject(2)+" "
                            +rs.getObject(3)+" "+rs.getObject(4)+" ");
                }
            }catch (SQLException e){
                e.printStackTrace();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void setSql_update(Connection conn,String sql) throws SQLException {
        try(PreparedStatement ps = conn.prepareStatement(sql);
        ) {
            ps.setString(1,"王五");
            ps.setInt(2,1);
            ps.executeUpdate();
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            e.printStackTrace();
        }
    }
    public static void setSql_delete(Connection conn,String sql) throws SQLException {
        try(PreparedStatement ps = conn.prepareStatement(sql);
        ) {
            ps.setInt(1,1);
            ps.executeUpdate();
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            e.printStackTrace();
        }
    }

    public static void batch_insert(Connection conn,String sql) throws SQLException {
        try(PreparedStatement ps = conn.prepareStatement(sql);
        ) {
            for (int i = 1; i <= 500; i++) {
                ps.setInt(1,i);
                ps.setString(2,"张"+i);
                ps.setString(3,"法律");
                ps.setString(4,"2000-01-01");
                ps.addBatch();
                if (i % 100 == 0){
                    ps.executeBatch();
                    ps.clearBatch();
                    System.out.println("已插入100条数据");
                }
            }
            ps.executeBatch();
            conn.commit();
            System.out.println("已全部插入");
        } catch (SQLException e) {
            conn.rollback();
            e.printStackTrace();
        }
    }

    public static void roll_select(Connection conn,String sql){
        try(PreparedStatement ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)
        ) {
            try(ResultSet rs = ps.executeQuery();) {
                rs.absolute(-2);
                System.out.println(rs.getInt("id") + " " + rs.getString("name"));
            }catch (SQLException e){
                e.printStackTrace();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

